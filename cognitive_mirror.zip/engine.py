
from voting import vote
from tree import build_tree
from logger import log

class CognitiveEngine:
    def __init__(self, agents, memory):
        self.agents = agents
        self.memory = memory

    def run(self, question):
        context = self.memory.get_context(question)
        log("Running strategies...")

        r1 = self.agents["s1"].run(question, context)
        r2 = self.agents["s2"].run(question, context)

        best = vote([r1, r2])
        log(f"Best decision: {best}")

        critique = self.agents["critic"].run(str(best), context)
        simulation = self.agents["sim"].run(str(best), context)

        tree = build_tree(best)

        return {
            "best": best,
            "tree": tree,
            "critique": critique,
            "simulation": simulation
        }
