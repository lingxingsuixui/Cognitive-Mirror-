
def llm_call(prompt):
    return '{"decision":"Option A","reason":"Balanced choice","score":0.8}'
