
from agent import Agent

def build_agents(llm_call):
    return {
        "s1": Agent("Strategist_A", "生成方案", llm_call),
        "s2": Agent("Strategist_B", "生成方案", llm_call),
        "critic": Agent("Critic", "批判", llm_call),
        "sim": Agent("Simulator", "模拟未来", llm_call),
    }
