
class Agent:
    def __init__(self, name, role, llm_call):
        self.name = name
        self.role = role
        self.llm_call = llm_call

    def run(self, task, context):
        prompt = f"""
角色: {self.name}
职责: {self.role}

上下文:
{context}

任务:
{task}

输出JSON:
{{
 "decision": "...",
 "reason": "...",
 "score": 0-1
}}
"""
        return self.llm_call(prompt)
