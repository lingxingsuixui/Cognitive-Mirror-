
import json

def vote(results):
    parsed = []
    for r in results:
        try:
            parsed.append(json.loads(r))
        except:
            continue

    best = max(parsed, key=lambda x: x.get("score", 0))
    return best
