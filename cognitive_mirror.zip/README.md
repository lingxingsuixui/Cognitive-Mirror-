
# Cognitive Mirror ULTRA

## Features
- Multi-agent competitive + voting
- Decision tree output
- Logging system
- Vector DB ready interface

## Run
pip install -r requirements.txt
python main.py
