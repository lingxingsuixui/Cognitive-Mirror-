
from memory import MemoryStore
from agents import build_agents
from engine import CognitiveEngine
from llm import llm_call

memory = MemoryStore()
memory.add("用户偏好稳定")
memory.add("对AI感兴趣")

agents = build_agents(llm_call)
engine = CognitiveEngine(agents, memory)

result = engine.run("是否转AI方向？")

for k,v in result.items():
    print("\n",k,"\n",v)
