
class MemoryStore:
    def __init__(self):
        self.memory = []

    def add(self, content):
        self.memory.append(content)

    def retrieve(self, query, top_k=5):
        return self.memory[-top_k:]

    def get_context(self, query):
        return "\n".join(self.retrieve(query))
