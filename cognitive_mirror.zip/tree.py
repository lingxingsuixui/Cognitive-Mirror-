
def build_tree(best):
    return f"""
Decision Tree:
{best['decision']} (score={best['score']})
 ├── Reason: {best['reason']}
 ├── Short-term: Stable
 ├── Long-term: Growth
 └── Risk: Medium
"""
